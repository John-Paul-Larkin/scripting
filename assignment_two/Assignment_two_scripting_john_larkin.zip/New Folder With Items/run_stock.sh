#!/bin/bash

# Run the Python script within the virtual environment
/Users/jpl/code/setu/scripting/assignment_two/ass_2_venv/bin/python /Users/jpl/code/setu/scripting/assignment_two/stock.py

